//
//  main.h
//  Challenge
//
//  Created by wanner on 20.09.13.
//  Copyright (c) 2013 Gerhard Wanner. All rights reserved.
//

#ifndef Challenge_main_h
#define Challenge_main_h

extern int REF_LAP;        // Runde, in der die Referenzzeit genommen wird
extern int TOTAL_LAP;      // Gesamtanzahl Runden
extern int BOX_TIME;       // Geschätzte Boxenzeit inkl. Ein- und Ausfahrt

#endif
